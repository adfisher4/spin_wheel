# spin_wheel
A graphical Python program that allows the user to spin a wheel with contestants names on it and it declares a winner upon completing the spin.
